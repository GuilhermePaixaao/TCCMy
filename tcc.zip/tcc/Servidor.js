const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const CargoRoteador = require("./backend/roteador/CargoRoteador");
const FuncionarioRoteador = require("./backend/roteador/FuncionarioRoteador");
const VisitanteRoteador = require("./backend/roteador/VisitanteRoteador");
const RegistroRoteador = require("./backend/roteador/RegistroRoteador");
const EmpresaRoteador = require("./backend/roteador/EmpresaRoteador");

module.exports = class Servidor {
    constructor() {
        this._porta = 8080;
        this._app = express();

        this._app.use(express.json());
        this._app.use(express.static("frontend"));
        this._app.use("/uploads", express.static(path.join(__dirname, "uploads"))); // permite acessar as imagens publicamente

        // 📂 Criar pasta uploads se não existir
        const uploadDir = path.join(__dirname, "uploads");
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }

        // 💾 Configuração do Multer
        const storage = multer.diskStorage({
            destination: (req, file, cb) => {
                cb(null, "uploads/");
            },
            filename: (req, file, cb) => {
                cb(null, `foto_${Date.now()}.png`);
            }
        });

        const upload = multer({ storage });

        // 📤 Rota de Upload com retorno do caminho do arquivo
        this._app.post("/upload", upload.single("photo"), (req, res) => {
            if (!req.file) {
                return res.status(400).json({ status: false, message: "Nenhuma foto enviada." });
            }

            const caminhoFoto = `/uploads/${req.file.filename}`; // caminho relativo acessível via navegador

            res.status(200).json({
                status: true,
                message: "Foto salva com sucesso!",
                filename: req.file.filename,
                path: caminhoFoto
            });
        });

        // 🔌 Inicialização dos roteadores
        this._cargoRoteador = new CargoRoteador();
        this._funcionarioRoteador = new FuncionarioRoteador();
        this._visitanteRoteador = new VisitanteRoteador();
        this._RegistroRoteador = new RegistroRoteador();
        this._EmpresaRoteador = new EmpresaRoteador();

        this.configurarRotas();
    }

    configurarRotas = () => {
        this._app.use("/cargos", this._cargoRoteador.criarRotasCargo());
        this._app.use("/funcionarios", this._funcionarioRoteador.criarRotasFuncionario());
        this._app.use("/visitantes", this._visitanteRoteador.criarRotasVisitante());
        this._app.use("/registro", this._RegistroRoteador.criarRotasRegistro());
        this._app.use("/empresas", this._EmpresaRoteador.criarRotasEmpresa());
    }

    iniciar = () => {
        this._app.listen(this._porta, () => {
            console.log(`API Rodando em http://localhost:${this._porta}/`);
        });
    }
}
