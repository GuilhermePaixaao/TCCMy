const express = require("express");
const RegistroControle = require("../controle/RegistroControle");
const JwtMiddleware = require("../middleware/JwtMiddleware");

module.exports = class RegistroRoteador {
    constructor() {
        this._router = express.Router();
        this._registroControle = new RegistroControle();
        this._jwtMiddleware = new JwtMiddleware();
    }

    criarRotasRegistro = () => {
        // Criar um novo registro de visita
        this._router.post("/",
            this._jwtMiddleware.validar_token_acesso, // Autenticação
            this._registroControle.registro_create_controle
        );

        // Atualizar horário de saída do registro
        this._router.put("/:idRegistro/saida",
            this._jwtMiddleware.validar_token_acesso, // Autenticação
            this._registroControle.registro_update_controle
        );

        // Obter todos os registros de visitas
        this._router.get("/", 
            this._jwtMiddleware.validar_token_acesso, // Autenticação
            this._registroControle.registro_readAll_controle
        );

        // Obter um registro específico pelo ID
        this._router.get("/:idRegistro", 
            this._jwtMiddleware.validar_token_acesso, // Autenticação
            this._registroControle.registro_readById_controle
        );

        // Deletar um registro pelo ID
        this._router.delete("/:idRegistro",
            this._jwtMiddleware.validar_token_acesso, // Autenticação
            this._registroControle.registro_delete_controle
        );

        return this._router;
    }
}
