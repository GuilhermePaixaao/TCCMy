const Banco = require("./banco");

module.exports = class Registro {
    constructor() {
        this._idRegistro = null;
        this._rgVisitante = null;
        this._idEmpresa = null;
        this._origem = null;
        this._horarioEntrada = null;
        this._horarioSaida = null;
        this._dataVisita = null;
        this._idFuncionario = null;
    }

    create = async () => {
        if (
            !this.rgVisitante ||
            !this.dataVisita ||
            !this.idFuncionario
        ) {
            console.log("Erro: Parâmetros obrigatórios ausentes:", {
                rgVisitante: this.rgVisitante,
                idEmpresa: this.idEmpresa,
                origem: this.origem,
                horarioEntrada: this.horarioEntrada,
                horarioSaida: this.horarioSaida,
                dataVisita: this.dataVisita,
                idFuncionario: this.idFuncionario,
            });
            return false;
        }

        const SQL = `INSERT INTO registro 
        (rgVisitante, idEmpresa, origem, horarioEntrada, horarioSaida, dataVisita, idFuncionario)
        VALUES (?, ?, ?, ?, ?, ?, ?)`;

        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [
                this.rgVisitante,
                this.idEmpresa,
                this.origem,
                this.horarioEntrada,
                this.horarioSaida,
                this.dataVisita,
                this.idFuncionario
            ]);
            this.idRegistro = resultado.insertId;
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log("Erro ao inserir registro:", error);
            return false;
        }
    };

    update = async () => {
        const SQL = `
            UPDATE registro 
            SET rgVisitante = ?, idEmpresa = ?, origem = ?, horarioEntrada = ?, 
                horarioSaida = ?, dataVisita = ?, idFuncionario = ?
            WHERE idRegistro = ?;
        `;

        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [
                this.rgVisitante,
                this.idEmpresa,
                this.origem,
                this.horarioEntrada,
                this.horarioSaida,
                this.dataVisita,
                this.idFuncionario,
                this.idRegistro
            ]);
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log("Erro ao atualizar registro:", error);
            return false;
        }
    };

    readAll = async () => {
        const SQL = "SELECT * FROM registro;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL);
            return resultado;
        } catch (error) {
            console.log(error);
            return [];
        }
    };

    readById = async () => {
        const SQL = "SELECT * FROM registro WHERE idRegistro = ?;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [this.idRegistro]);
            return resultado;
        } catch (error) {
            console.log(error);
            return [];
        }
    };

    delete = async () => {
        const SQL = "DELETE FROM registro WHERE idRegistro = ?;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [this.idRegistro]);
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log(error);
            return false;
        }
    };

    // Getters e Setters
    get idRegistro() { return this._idRegistro; }
    set idRegistro(value) { this._idRegistro = value; }

    get rgVisitante() { return this._rgVisitante; }
    set rgVisitante(value) { this._rgVisitante = value; }

    get idEmpresa() { return this._idEmpresa; }
    set idEmpresa(value) { this._idEmpresa = value; }

    get origem() { return this._origem; }
    set origem(value) { this._origem = value; }

    get horarioEntrada() { return this._horarioEntrada; }
    set horarioEntrada(value) { this._horarioEntrada = value; }

    get horarioSaida() { return this._horarioSaida; }
    set horarioSaida(value) { this._horarioSaida = value; }

    get dataVisita() { return this._dataVisita; }
    set dataVisita(value) { this._dataVisita = value; }

    get idFuncionario() { return this._idFuncionario; }
    set idFuncionario(value) { this._idFuncionario = value; }
};
