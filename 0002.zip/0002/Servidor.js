const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const CargoRoteador = require("./backend/roteador/CargoRoteador");
const FuncionarioRoteador = require("./backend/roteador/FuncionarioRoteador");
const VisitanteRoteador = require("./backend/roteador/VisitanteRoteador");
const RegistroRoteador = require("./backend/roteador/RegistroRoteador");
const EmpresaRoteador = require("./backend/roteador/EmpresaRoteador");
const UploadsRoteador = require("./backend/roteador/UploadsRoteador");
const PlanilhaRoteador = require("./backend/roteador/PlanilhaRoteador");


module.exports = class Servidor {
    constructor() {
        this._porta = 8080;
        this._app = express();

        this._app.use(express.json());
        this._app.use(express.static("frontend"));

        this._cargoRoteador = new CargoRoteador();
        this._funcionarioRoteador = new FuncionarioRoteador();
        this._visitanteRoteador = new VisitanteRoteador();
        this._RegistroRoteador = new RegistroRoteador();
        this._EmpresaRoteador = new EmpresaRoteador();
        this._UploadsRoteador = new UploadsRoteador();
        this._PlanilhaRoteador = new PlanilhaRoteador();

        this.configurarRotas();
    }

    configurarRotas = () => {
        this._app.use("/cargos", this._cargoRoteador.criarRotasCargo());
        this._app.use("/funcionarios", this._funcionarioRoteador.criarRotasFuncionario());
        this._app.use("/visitantes", this._visitanteRoteador.criarRotasVisitante());
        this._app.use("/registro", this._RegistroRoteador.criarRotasRegistro());
        this._app.use("/empresas", this._EmpresaRoteador.criarRotasEmpresa());
        this._app.use("/uploads", this._UploadsRoteador.criarRotasUpload());
        this._app.use("/planilha", this._PlanilhaRoteador.criarRotasPlanilha());
    }

    iniciar = () => {
        this._app.listen(this._porta, () => {
            console.log(`API Rodando em http://localhost:${this._porta}/login/login.html`);
        });
    }
}
