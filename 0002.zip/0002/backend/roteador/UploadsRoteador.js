const express = require("express");
const {
  UploadControle,
  buscarFotoPorCPF,
  buscarTodasFotoPorCPF,
} = require("../controle/UploadsControle");
const upload = require("../middleware/UploadsMulter");
const JwtMiddleware = require("../middleware/JwtMiddleware");

module.exports = class UploadRoteador {
  constructor() {
    this._router = express.Router();
    this._uploadsControle = new UploadControle();
    this._jwtMiddleware = new JwtMiddleware();
  }

  criarRotasUpload = () => {
    this._router.post(
      "/",
      upload.single("photo"),
      this._uploadsControle.uploadFoto
    );

    this._router.get(
      "/todasFoto/:cpf",
      this._jwtMiddleware.validar_token_acesso,
      buscarTodasFotoPorCPF
    );

    this._router.get(
      "/:cpf",
      this._jwtMiddleware.validar_token_acesso,
      buscarFotoPorCPF
    );

    return this._router;
  };
};
