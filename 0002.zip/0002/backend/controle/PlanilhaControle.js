const PlanilhaModelo = require("../modelo/Planilha");
const path = require("path");
const fs = require("fs");
const PDFDocument = require("pdfkit");

/* ─── Função utilitária ───────────────────────────────────────── */
function formatarDataBr(data) {
  const dataObj = typeof data === "string" ? new Date(data) : data;
  if (!dataObj || isNaN(dataObj.getTime())) return "";
  return dataObj.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

/* ─── Classe de controle ──────────────────────────────────────── */
module.exports = class PlanilhaControle {
  constructor() {
    this._modelo = new PlanilhaModelo();
  }

  gerarPlanilha = async () => {
    const dados = await this._modelo.buscarTodosClientes();
    if (!dados || !dados.length) throw new Error("Nenhum dado encontrado.");
    return this._gerarPDF(dados, "Controle_de_Acesso.pdf");
  };

  gerarPlanilhaPorCPF = async (cpf) => {
  const dados = await this._modelo.buscarClientesPorCPF(cpf);
  if (!dados || !dados.length) throw new Error("Nenhum dado encontrado para o CPF informado.");
  return this._gerarPDF(dados, `Relatorio_CPF.pdf`);
};


  gerarPlanilhaPorEmpresa = async (nomeEmpresa) => {
    const dados = await this._modelo.buscarClientesPorEmpresa(nomeEmpresa);
    if (!dados || !dados.length) throw new Error("Nenhum dado encontrado para a empresa informada.");
    const nomeLimpo = nomeEmpresa.replace(/[^a-zA-Z0-9]/g, "_");
    return this._gerarPDF(dados, `Relatorio_Empresa_${nomeLimpo}.pdf`);
  };
  // Dentro da classe PlanilhaControle:

gerarPlanilhaPorPeriodo = async (dataInicial, dataFinal) => {
  const dados = await this._modelo.buscarClientesPorPeriodo(dataInicial, dataFinal);
  if (!dados || !dados.length) {
    throw new Error("Nenhum dado encontrado para o período informado.");
  }
  const nomeArquivo = `Relatorio_Periodo_${dataInicial.replace(/-/g, "")}_ate_${dataFinal.replace(/-/g, "")}.pdf`;
  return this._gerarPDF(dados, nomeArquivo);
};
gerarPlanilhaPorFuncionario = async (nomeFuncionario) => {
  const dados = await this._modelo.buscarClientesPorFuncionario(nomeFuncionario);
  if (!dados || !dados.length) throw new Error("Nenhum dado encontrado para o funcionário informado.");
  const nomeLimpo = nomeFuncionario.replace(/[^a-zA-Z0-9]/g, "_");
  return this._gerarPDF(dados, `Relatorio_Funcionario_${nomeLimpo}.pdf`);
};

  _gerarPDF = (dados, nomeArquivo) => {
    const caminho = path.resolve(__dirname, "../../planilhas", nomeArquivo);
    fs.mkdirSync(path.dirname(caminho), { recursive: true });

    const TITLE_FONT_SIZE = 24;
    const HEADER_FONT_SIZE = 12;
    const BODY_FONT_SIZE = 12;
    const HEADER_HEIGHT = 40;
    const ROW_PADDING_Y = 10;

    const doc = new PDFDocument({ margin: 40, size: "A4" });
    const stream = fs.createWriteStream(caminho);
    doc.pipe(stream);

    doc
      .font("Helvetica-Bold")
      .fontSize(TITLE_FONT_SIZE)
      .fillColor("#333")
      .text("Relatório de Controle de Acesso", { align: "center" })
      .moveDown();

    const mapaColunas = {
      cpf: "CPF",
      horarioEntrada: "Horário de Entrada",
      horarioSaida: "Horário de Saída",
      origem: "Origem",
      dataVisita: "Data da Visita",
      nomeEmpresa: "Empresa",
      nomeFuncionario: "Funcionário",
    };

    const colunas = Object.keys(mapaColunas);
    const margemEsq = doc.page.margins.left;
    const larguraPagina = doc.page.width - margemEsq - doc.page.margins.right;
    const larguraColuna = larguraPagina / colunas.length;
    let y = doc.y;

    const desenharCabecalho = () => {
      doc.rect(margemEsq, y, larguraPagina, HEADER_HEIGHT).fill("#f0f0f0");
      doc.fillColor("#000").font("Helvetica-Bold").fontSize(HEADER_FONT_SIZE);
      colunas.forEach((col, i) => {
        doc.text(
          mapaColunas[col],
          margemEsq + i * larguraColuna + 2,
          y + (HEADER_HEIGHT - HEADER_FONT_SIZE) / 2,
          { width: larguraColuna - 4, align: "center" }
        );
      });
      y += HEADER_HEIGHT + 8;
      doc.font("Helvetica").fontSize(BODY_FONT_SIZE);
    };

    desenharCabecalho();

    dados.forEach((linha, index) => {
      const valores = [];
      let alturaMax = 0;

      colunas.forEach((col) => {
        let v = linha[col];
        if (v instanceof Date) {
          v = formatarDataBr(v);
        } else if (typeof v === "string") {
          const limpo = v.replace(/\n/g, " ").replace(/\(.*?\)/g, "").trim();
          const dObj = new Date(limpo);
          if (!isNaN(dObj.getTime())) {
            v = formatarDataBr(dObj);
          } else {
            const m = limpo.match(/(\d{4})-(\d{2})-(\d{2})/);
            v = m ? `${m[3]}/${m[2]}/${m[1]}` : limpo;
          }
        } else {
          v = String(v ?? "");
        }

        valores.push(v);
        const h = doc.heightOfString(v, {
          width: larguraColuna - 4,
          align: "center",
        });
        alturaMax = Math.max(alturaMax, h);
      });

      const alturaLinha = alturaMax + ROW_PADDING_Y;

      if (y + alturaLinha > doc.page.height - doc.page.margins.bottom) {
        doc.addPage();
        y = doc.y;
        desenharCabecalho();
      }

      if (index % 2 === 0) {
        doc.rect(margemEsq, y, larguraPagina, alturaLinha).fill("#f9f9f9");
      }

      valores.forEach((v, i) => {
        doc
          .fillColor("#000")
          .text(
            v,
            margemEsq + i * larguraColuna + 2,
            y + ROW_PADDING_Y / 2,
            { width: larguraColuna - 4, align: "center" }
          );
      });

      y += alturaLinha;
    });

    doc.end();

    return new Promise((resolve, reject) => {
      stream.on("finish", () => resolve(caminho));
      stream.on("error", reject);
    });
  };

  filtroby_empresa = async (request, response) => {
    console.log("PlanilhaControle.filtroby_empresa()");

    const nome = request.query.nomeEmpresa;

    if (!nome || typeof nome !== "string") {
      return response.status(400).send({
        status: false,
        msg: "Parâmetro 'nomeEmpresa' é obrigatório e deve ser uma string.",
      });
    }

    try {
      const dados = await this._modelo.buscarClientesPorEmpresa(nome);

      return response.status(200).send({
        status: true,
        msg: "Consulta realizada com sucesso!",
        dados: dados,
      });
    } catch (error) {
      console.error("Erro ao filtrar empresa:", error);
      return response.status(500).send({
        status: false,
        msg: "Erro ao consultar empresa.",
      });
    }
  };
};
