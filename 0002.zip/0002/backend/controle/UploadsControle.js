const path = require("path");
const {getFotoMaisRecentePorCPF, getTodasFotosPorCPF} = require("../modelo/Uploads");

class UploadControle {
    uploadFoto = (req, res) => {
        if (!req.file) {
            return res.status(400).json({ status: false, message: "Nenhuma foto enviada." });
        }

        const caminhoFoto = `/uploads/${req.file.filename}`;

        res.status(200).json({
            status: true,
            message: "Foto salva com sucesso!",
            filename: req.file.filename,
            path: caminhoFoto
        });
    }   
};

function buscarFotoPorCPF(req, res){
    console.log("UploadControle.buscarFotoPorCPF()");
    const {cpf} = req.params;

    if (!cpf){
        return res.status(400).json({erro: "cpf não fornecido"});
    }

    const caminhoFoto = getFotoMaisRecentePorCPF(cpf);

    res.json({caminho: caminhoFoto});
}

function buscarTodasFotoPorCPF(req, res) {
    const { cpf } = req.params;
  
    if (!cpf) {
      return res.status(400).json({ erro: "cpf não fornecido" });
    }
  
    const fotos = getTodasFotosPorCPF(cpf);
  
    if (fotos.length > 0) {
      res.json({ imagens: fotos });
    } else {
      res.status(404).json({ imagens: [] });
    }
  }
  

module.exports = {
    UploadControle,
    buscarFotoPorCPF,
    buscarTodasFotoPorCPF};