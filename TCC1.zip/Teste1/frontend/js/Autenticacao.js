function getPayloadFromToken(){

    const token = localStorage.getItem('token');
    if (!token) return null;

    try{
        const payloadBase64 = token.split('.')[1];
        const payload = JSON.parse(atob(payloadBase64));
        return payload;
    }catch (e){
        console.error('Token inválido ou malformado');
        return null;
    }
}

function getRoleFromToken(){
    const payload = getPayloadFromToken();
      if (payload) {
        return payload.role;
      } 
}

function verificacaoAdm(){
    const token = localStorage.getItem("token");
    if (!token) {
        alert("Erro: Você precisa estar logado.");
        window.location.href = '/login/login.html'
        return;
    }
    
    const role = getRoleFromToken();
    if(role !== "adm"){
        alert('Acesso Negado! Apenas para Administradores');
        window.location.href = '/login/index/funcionario/indexFun.html'
        return;
    }
}

function verificacaoLogin(){
    const token = localStorage.getItem('token');
    if (!token) {
        alert("Erro: Você precisa estar logado.");
        window.location.href = '/login/login.html'
        return;
    }
}

function Inicio(){
    const role = getRoleFromToken(); 
    if (role === 'adm'){
        console.log('erro')
        window.location.href = '/login/index/adm/indexAdm.html';
        return;
    }else if(role === 'funcionario'){
        console.log('erro')
        window.location.href = '/login/index/funcionario/indexFun.html';
        return;
    }
}

function InicioVisitante(){
    const role = getRoleFromToken();
    if (role === 'adm'){
        window.location.href = '/login/index/adm/visitante/indexVisitanteAdm.html';
    }else if(role === 'funcionario'){
        window.location.href = '/login/index/funcionario/visitante/indexVisitanteFun.html';
    }
}
