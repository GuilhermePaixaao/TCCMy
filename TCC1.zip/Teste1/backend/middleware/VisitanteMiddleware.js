const { status } = require("express/lib/response");
const MeuTokenJWT = require('../modelo/MeuTokenJWT')

module.exports = class VisitanteMiddleware {
    validar_nomeVisitante = async (request, response, next) => {
    console.log("Middleware - request.body:", request.body);
    const nomeVisitante = request.body.visitante?.nomeVisitante;

    if (!nomeVisitante || nomeVisitante.length < 3) {
        return response.status(400).send({
            status: false,
            msg: "O nome do visitante deve ter pelo menos 3 caracteres.",
        });
    }
    next();
};


    validar_rgVisitante = (request, response, next) => {
    const rgVisitante = request.body.visitante?.rgVisitante || request.body.novoRgVisitante || request.body.rgVisitante;

    if (!rgVisitante || rgVisitante.length < 9) {
        return response.status(400).send({
            status: false,
            msg: "O RG do visitante deve ter pelo menos 9 caracteres.",
        });
    }
    next();
};

    
    validar_entrada = (request, response, next) => {
        const horarioEntrada = request.body.horarioEntrada;

        if (!horarioEntrada) {
            return response.status(400).send({
                status: false,
                msg: "O horário de entrada deve ser informado.",
            });
        }
        next();
    };
};
