function getPayloadFromToken(token){
    try{
        const payloadBase64 = token.split('.')[1];
        const payloadDecoded = atob(payloadBase64);
        return JSON.parse(payloadDecoded);

    }catch (e){
        return null;
    }
}

function verificarPermissaoAcesso(){
    const token = localStorage.getItem('token')
    if (!token){
        window.location.href = 'login.html';
    }

    const payload = getPayloadFromToken(token);

    if (!payload || !payload.idCargo){
        window.location.href = 'login.html';
        return;
    } 

    const idCargo = payload.idCargo;

    if (idCargo === 1 ){
        const adminSections = document.querySelectorAll('.admin-section');
        adminSections.forEach(section => {
            section.style.display = 'block';
        });
    }
}

