const multer = require("multer");
const path = require("path");
const fs = require("fs");

// Caminho absoluto para a pasta 'frontend/uploads'
const uploadDir = path.join(__dirname, '..', '..', 'frontend','xdata_srv');

// Cria a pasta 'uploads' dentro de 'frontend', se não existir
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// Configuração do multer
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        // Usa o nome original enviado pelo frontend (ex: 12345678.png)
        cb(null, file.originalname);
    }
});

const upload = multer({ storage });

module.exports = upload;
