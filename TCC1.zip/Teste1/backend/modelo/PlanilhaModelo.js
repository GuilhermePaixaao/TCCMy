const Banco = require("./banco"); // ajuste o caminho se necessário

module.exports = class PlanilhaModelo {
    async buscarDadosClientes() {
        const conexao = Banco.getConexao(); // obtém a conexão (que é do tipo mysql2 Connection)
        // Usar Promise para a query pois o método 'execute' não retorna Promise por padrão com createConnection sem promise
        return new Promise((resolve, reject) => {
            conexao.execute(
                `SELECT dataVisita, origem, horarioEntrada, horarioSaida from registro `,
                (erro, resultados) => {
                    if (erro) {
                        reject(erro);
                    } else {
                        resolve(resultados);
                    }
                }
            );
        });
    }
};
