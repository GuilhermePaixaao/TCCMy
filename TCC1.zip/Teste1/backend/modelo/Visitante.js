const Banco = require("./banco");

module.exports = class Visitante {
    constructor() {
        this._nomeVisitante = null;
        this._rgVisitante = null;
        this._empresaVisitante = null;
        this._origemVisitante = null;
        this._horarioEntrada = null;
        this._horarioSaida = null;
    }

    // Criação de um novo visitante
    create = async () => {
        const SQL = "INSERT INTO Visitante (nome, rg) VALUES (?, ?);";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL,
                [this.nomeVisitante, this.rgVisitante]);
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log(error);
            return false;
        }
    }

    // Lê todos os visitantes
    readAll = async () => {
        const SQL = "SELECT * FROM Visitante;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, []);
            return resultado;
        } catch (error) {
            console.log(error);
            return [];
        }
    }

    // Lê um visitante específico pelo RG
    readByRg = async () => {
        const SQL = "SELECT * FROM Visitante WHERE rg = ?;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [this.rgVisitante]);
            return resultado;
        } catch (error) {
            console.log(error);
            return [];
        }
    }

    // Atualiza o visitante, permite alterar nome, RG e caminhoFoto (se enviados)
    update = async () => {
        const conexao = Banco.getConexao().promise();

        try {
            await conexao.query('START TRANSACTION');

            // Atualiza Visitante primeiro
            let SQL = 'UPDATE Visitante SET nome = ?';
            const params = [this.nomeVisitante];

            if (this.novoRgVisitante) {
                SQL += ', rg = ?';
                params.push(this.novoRgVisitante);
            }
            
            

            SQL += ' WHERE rg = ?';
            params.push(this.rgVisitante);

            const [resultado] = await conexao.execute(SQL, params);

            // Se tiver novoRgVisitante, atualiza registro depois
            if (this.novoRgVisitante) {
                const sqlRegistro = 'UPDATE registro SET rg = ? WHERE rg = ?';
                await conexao.execute(sqlRegistro, [this.novoRgVisitante, this.rgVisitante]);
            }

            await conexao.query('COMMIT');

            return resultado.affectedRows > 0;

        } catch (error) {
            await conexao.query('ROLLBACK');
            console.log('Erro no update do visitante com transação:', error);
            return false;
        }
    }



    delete = async () => {
        const SQL = "DELETE FROM Visitante WHERE rg = ?;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [this.rgVisitante]);
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log(error);
            return false;
        }
    }

    // Getters and Setters
    get nomeVisitante() { return this._nomeVisitante; }
    set nomeVisitante(value) { this._nomeVisitante = value; }

    get rgVisitante() { return this._rgVisitante; }
    set rgVisitante(value) { this._rgVisitante = value; }

    get empresaVisitante() { return this._empresaVisitante; }
    set empresaVisitante(value) { this._empresaVisitante = value; }

    get origemVisitante() { return this._origemVisitante; }
    set origemVisitante(value) { this._origemVisitante = value; }

    get horarioEntrada() { return this._horarioEntrada; }
    set horarioEntrada(value) { this._horarioEntrada = value; }

    get horarioSaida() { return this._horarioSaida; }
    set horarioSaida(value) { this._horarioSaida = value; }

    get novoRgVisitante() { return this._novoRgVisitante; }
    set novoRgVisitante(value) { this._novoRgVisitante = value; }

    get caminhoFoto() { return this._caminhoFoto; }
    set caminhoFoto(value) { this._caminhoFoto = value; }


};
