const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

function getFotoMaisRecentePorRG(rg){
    const hashRG = crypto.createHash("md5").update(rg).digest("hex");
    const pastaFotos = path.join(__dirname, "..", "xdata_srv");
    console.log(hashRG);
    const aquivos = fs.readdirSync(pastaFotos);

    const aquivosDoRG = aquivos
        .filter(nome => nome.startsWith(hashRG))
        .sort((a, b) => {
            const timestampA = parseInt(a.split("_")[1]);
            const timestampB = parseInt(b.split("_")[1]);
            return timestampB - timestampA;
        });

        if (aquivosDoRG.length >0){
            return `/xdata_srv/${aquivosDoRG[0]}`;
        }

}

module.exports = {getFotoMaisRecentePorRG}