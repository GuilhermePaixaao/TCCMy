const Banco = require("./banco"); // ajuste o caminho se necessário

module.exports = class PlanilhaModelo {
    async buscarDadosClientes() {
        const conexao = Banco.getConexao(); // obtém a conexão (que é do tipo mysql2 Connection)
        // Usar Promise para a query pois o método 'execute' não retorna Promise por padrão com createConnection sem promise
        return new Promise((resolve, reject) => {
            conexao.execute(
                ` 
     SELECT 
    visitante.rg,
    registro.horarioEntrada,
    registro.horarioSaida,
    registro.origem,
    registro.dataVisita,
    empresa.nomeEmpresa,
    funcionario.nomeFuncionario
FROM 
    registro
JOIN 
    visitante ON registro.idVisitante = visitante.idVisitante
JOIN 
    empresa ON registro.idEmpresa = empresa.idEmpresa
JOIN 
    funcionario ON registro.idFuncionario = funcionario.idFuncionario;

      
        `,
                (erro, resultados) => {
                    if (erro) {
                        reject(erro);
                    } else {
                        resolve(resultados);
                    }
                }
            );
        });
    }
};