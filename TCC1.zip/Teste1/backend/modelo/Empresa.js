const Banco = require("./banco");

module.exports = class Empresa {
    constructor() {
        this._idEmpresa = null;
        this._nomeEmpresa = null;
        this._cnpjEmpresa = null;
    }

    create = async () => {
        const SQL = "INSERT INTO empresa (nomeEmpresa, cnpjEmpresa) VALUES (?, ?)";
        try {
            console.log("Executando create com nomeEmpresa:", this.nomeEmpresa, this.cnpjEmpresa);
            const conexao = Banco.getConexao();
            const [resposta] = await conexao.promise().execute(SQL, [this.nomeEmpresa, this.cnpjEmpresa]);
            console.log("Resposta da execução do create:", resposta);
            this.idEmpresa = resposta.insertId;
            return resposta.affectedRows > 0;
        } catch (error) {
            console.error("Erro no create:", error);
            return false;
        }
    }

    delete = async () => {
        const SQL = "DELETE FROM empresa WHERE idEmpresa = ?";
        try {
            console.log("Executando delete com idEmpresa:", this.idEmpresa);
            const conexao = Banco.getConexao();
            const [resposta] = await conexao.promise().execute(SQL, [this.idEmpresa]);
            console.log("Resposta da execução do delete:", resposta);
            return resposta.affectedRows > 0;
        } catch (error) {
            console.error("Erro no delete:", error);
            return false;
        }
    }

    update = async () => {
        const SQL = "UPDATE empresa SET nomeEmpresa = ? WHERE idEmpresa = ?";
        try {
            console.log("Executando update com nomeEmpresa:", this.nomeEmpresa, "idEmpresa:", this.idEmpresa);
            const conexao = Banco.getConexao();
            const [resposta] = await conexao.promise().execute(SQL, [this.nomeEmpresa, this.idEmpresa]);
            console.log("Resposta da execução do update:", resposta);
            return resposta.affectedRows > 0;
        } catch (error) {
            console.error("Erro no update:", error);
            return false;
        }
    }

    isEmpresa = async () => {
        const SQL = "SELECT COUNT(*) AS qtd FROM empresa WHERE nomeEmpresa = ?";
        try {
            console.log("Verificando existência da empresa com nomeEmpresa:", this.nomeEmpresa);
            const conexao = Banco.getConexao();
            const [resposta] = await conexao.promise().execute(SQL, [this.nomeEmpresa]);
            console.log("Resultado da verificação da empresa:", resposta);
            return resposta[0].qtd > 0;
        } catch (error) {
            console.error("Erro na verificação da empresa:", error);
            return false;
        }
    }

    isEmpresaById = async () => {
        const SQL = "SELECT COUNT(*) AS qtd FROM empresa WHERE idEmpresa = ?";
        try {
            console.log("Verificando existência da empresa com idEmpresa:", this.idEmpresa);
            const conexao = Banco.getConexao();
            const [resposta] = await conexao.promise().execute(SQL, [this.idEmpresa]);
            console.log("Resultado da verificação da empresa:", resposta);
            return resposta[0].qtd > 0;
        } catch (error) {
            console.error("Erro na verificação da empresa:", error);
            return false;
        }
    }

    readAll = async () => {
        const SQL = "SELECT * FROM empresa";
        try {
            console.log("Buscando todas as empresas...");
            const conexao = Banco.getConexao();
            const [matrizRespostas] = await conexao.promise().execute(SQL);
            console.log("Resultado da busca por todas as empresas:", matrizRespostas);
            return matrizRespostas;
        } catch (error) {
            console.error("Erro ao buscar todas as empresas:", error);
            return [];
        }
    }

    readById = async () => {
        const SQL = "SELECT * FROM empresa WHERE idEmpresa = ?";
        try {
            console.log("Buscando empresa pelo ID:", this.idEmpresa);
            const conexao = Banco.getConexao();
            const [matrizRespostas] = await conexao.promise().execute(SQL, [this.idEmpresa]);
            console.log("Resultado da busca pelo ID:", matrizRespostas);
            return matrizRespostas;
        } catch (error) {
            console.error("Erro ao buscar empresa pelo ID:", error);
            return [];
        }
    }

    get idEmpresa() {
        return this._idEmpresa;
    }
    set idEmpresa(novoIdEmpresa) {
        this._idEmpresa = novoIdEmpresa;
    }

    get cnpjEmpresa(){
        return this._cnpjEmpresa;
    }

    set cnpjEmpresa(novoCnpjEmpresa){
        this._cnpjEmpresa = novoCnpjEmpresa;
    }

    get nomeEmpresa() {
        return this._nomeEmpresa;
    }
    set nomeEmpresa(novoNomeEmpresa) {
        this._nomeEmpresa = novoNomeEmpresa;
    }
}
