const Empresa = require("../modelo/Empresa");
const { response } = require("express");
const { status } = require("express/lib/response");

module.exports = class EmpresaControle {
    empresa_create_controle = async (request, response) => {
        console.log("EmpresaControle.empresa_create_controle");

        const empresa = new Empresa();
        empresa.nomeEmpresa = request.body.empresa.nomeEmpresa;
        empresa.cnpjEmpresa = request.body.empresa.cnpjEmpresa;

        const objResposta = {
            status: true,
            msg: "Cadastrado com sucesso",
            token: null
        }

        const criou = await empresa.create();
        if (criou === false) {
            objResposta.status = false;
            objResposta.msg = "Erro ao cadastrar";
            response.status(500).send(objResposta);
        } else {
            objResposta.token = request.headers.authorization;
            response.status(201).send(objResposta);
        }
    }

    empresa_readAll_controle = async (request, response) => {
        console.log("EmpresaControle.empresa_readAll_controle()");
        const empresa = new Empresa();
        const objResposta = {
            status: true,
            msg: "Executado com sucesso",
            dados: await empresa.readAll(),
        }
        response.status(200).send(objResposta);
    }

    empresa_readById_controle = async (request, response) => {
        console.log("EmpresaControle.empresa_readById_controle()");

        const empresa = new Empresa();
        empresa.idEmpresa = request.params.idEmpresa;

        const objResposta = {
            status: true,
            msg: "Executado com sucesso",
            dados: await empresa.readById(),
        }
        response.status(200).send(objResposta);
    }

    empresa_update_controle = async (request, response) => {
        console.log("EmpresaControle.empresa_update_controle()");

        const empresa = new Empresa();
        empresa.cnpjEmpresa = request.params.cnpjEmpresa;
        empresa.nomeEmpresa = request.body.empresa.nomeEmpresa;

        const objResposta = {
            status: await empresa.update(),
            msg: "Executado com sucesso",
        }
        response.status(200).send(objResposta);
    }

    empresa_delete_controle = async (request, response) => {
        console.log("EmpresaControle.empresa_delete_controle()");

        const empresa = new Empresa();
        empresa.idEmpresa = request.params.idEmpresa;

        const objResposta = {
            status: await empresa.delete(),
            msg: "Executado com sucesso",
        }
        response.status(200).send(objResposta);
    }
}


