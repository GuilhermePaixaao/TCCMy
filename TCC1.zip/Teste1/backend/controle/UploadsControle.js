const path = require("path");
const {getFotoMaisRecentePorRG} = require("../modelo/Uploads");

class UploadControle {
    uploadFoto = (req, res) => {
        if (!req.file) {
            return res.status(400).json({ status: false, message: "Nenhuma foto enviada." });
        }

        const caminhoFoto = `/uploads/${req.file.filename}`;

        res.status(200).json({
            status: true,
            message: "Foto salva com sucesso!",
            filename: req.file.filename,
            path: caminhoFoto
        });
    }   
};

function buscarFotoPorRG(req, res){
    const {rg} = req.params;

    if (!rg){
        return res.status(400).json({erro: "RG não fornecido"});
    }

    const caminhoFoto = getFotoMaisRecentePorRG(rg);
    res.json({caminho: caminhoFoto});
}

module.exports = {
    UploadControle,
    buscarFotoPorRG};
