const Visitante = require("../modelo/Visitante");

module.exports = class VisitanteControle {

    visitante_create_controle = async (request, response) => {
        console.log("VisitanteControle.visitante_create_controle()");
        console.log("Corpo recebido:", request.body);

        const visitante = new Visitante();
        visitante.nomeVisitante = request.body.visitante.nomeVisitante;
        visitante.rgVisitante = request.body.visitante.rgVisitante;

        const objResposta = {
            status: true,
            msg: "Visitante cadastrado com sucesso!",
        };

        const criou = await visitante.create();
        if (!criou) {
            objResposta.status = false;
            objResposta.msg = "Erro ao cadastrar visitante.";
            response.status(500).send(objResposta);
        } else {
            response.status(201).send(objResposta);
        }
    };

    visitante_readAll_controle = async (request, response) => {
        console.log("VisitanteControle.visitante_readAll_controle()");

        const visitante = new Visitante();
        const objResposta = {
            status: true,
            msg: "Consulta realizada com sucesso!",
            dados: await visitante.readAll(),
        };
        response.status(200).send(objResposta);
    };

    visitante_readById_controle = async (request, response) => {
        console.log("VisitanteControle.visitante_readById_controle()");

        const visitante = new Visitante();
        visitante.rgVisitante = request.params.rgVisitante;

        const objResposta = {
            status: true,
            msg: "Consulta realizada com sucesso!",
            dados: await visitante.readById(),
        };
        response.status(200).send(objResposta);
    };

    visitante_update_controle = async (request, response) => {
        console.log("VisitanteControle.visitante_update_controle()");
        console.log("Corpo recebido:", request.body);
        

        const visitante = new Visitante();
        visitante.rgVisitante = request.params.rgVisitante;
        visitante.nomeVisitante = request.body.nomeVisitante;
        visitante.novoRgVisitante = request.body.novoRgVisitante; // ADICIONAR
        visitante.caminhoFoto = request.body.caminhoFoto; // ADICIONAR

        const sucesso = await visitante.update();

        const objResposta = {
            status: sucesso,
            msg: sucesso ? "Visitante atualizado com sucesso!" : "Erro ao atualizar visitante.",
        };

        response.status(sucesso ? 200 : 400).send(objResposta); // retorna 400 se não atualizou
    };


    visitante_delete_controle = async (request, response) => {
        console.log("VisitanteControle.visitante_delete_controle()");

        const visitante = new Visitante();
        visitante.rgVisitante = request.params.rgVisitante;

        const objResposta = {
            status: await visitante.delete(),
            msg: "Visitante excluído com sucesso!",
        };

        response.status(200).send(objResposta);
    };
};