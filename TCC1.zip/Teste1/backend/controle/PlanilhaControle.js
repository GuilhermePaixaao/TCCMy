const PlanilhaModelo = require("../modelo/Planilha");
const ExcelJS = require("exceljs");
const path = require("path");
const fs = require("fs");
const PDFDocument = require("pdfkit");

function formatarDataBr(data) {
    const dataObj = typeof data === 'string' ? new Date(data) : data;

    if (!dataObj || isNaN(dataObj.getTime())) return "";

  return dataObj.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        
    });
}

module.exports = class PlanilhaControle {
    constructor() {
        this._modelo = new PlanilhaModelo();
    }

    gerarPlanilha = async () => {
        const dados = await this._modelo.buscarDadosClientes();

        if (!dados || dados.length === 0) {
            throw new Error("Nenhum dado encontrado.");
        }

        const caminho = path.resolve(__dirname, "../../planilhas/Controle de Acesso.pdf");

        const pasta = path.dirname(caminho);
        if (!fs.existsSync(pasta)) {
            fs.mkdirSync(pasta, { recursive: true });
        }

        const doc = new PDFDocument({ margin: 40, size: 'A4' });
        const stream = fs.createWriteStream(caminho);
        doc.pipe(stream);

        // Título do relatório
        doc
            .fontSize(20)
            .fillColor('#333')
            .font('Helvetica-Bold')
            .text("Relatório de Controle de Acesso", { align: "center" })
            .moveDown(2);

        const mapaColunas = {
            rg: "RG",
            horarioEntrada: "Horário de Entrada",
            horarioSaida: "Horário de Saída",
            origem: "Origem",
            dataVisita: "Data da Visita",
            nomeEmpresa: "Empresa",
            nomeFuncionario: "Funcionário"
        };

        const colunas = Object.keys(mapaColunas);
        const larguraPagina = doc.page.width - doc.page.margins.left - doc.page.margins.right;
        const larguraColuna = larguraPagina / colunas.length;
        let y = doc.y;

        // Cabeçalho da tabela
        doc.rect(doc.page.margins.left, y, larguraPagina, 20).fill('#f0f0f0');
        doc.fillColor('#000').fontSize(10).font("Helvetica-Bold");
        colunas.forEach((col, i) => {
            doc.text(mapaColunas[col], doc.page.margins.left + i * larguraColuna + 2, y + 5, {
                width: larguraColuna - 4,
                align: "center"
            });
        });

        y += 25;
        doc.font("Helvetica").fontSize(9);

        dados.forEach((linha, index) => {
            if (y > doc.page.height - doc.page.margins.bottom - 30) {
                doc.addPage();
                y = doc.y;

                doc.rect(doc.page.margins.left, y, larguraPagina, 20).fill('#f0f0f0');
                doc.fillColor('#000').font("Helvetica-Bold");
                colunas.forEach((col, i) => {
                    doc.text(mapaColunas[col], doc.page.margins.left + i * larguraColuna + 2, y + 5, {
                        width: larguraColuna - 4,
                        align: "center"
                    });
                });
                y += 25;
                doc.font("Helvetica").fontSize(9);
            }

            if (index % 2 === 0) {
                doc.rect(doc.page.margins.left, y, larguraPagina, 15).fill('#f9f9f9');
            }

            doc.fillColor('#000');
            colunas.forEach((col, i) => {
                let valor = linha[col];

                if (typeof valor === "string" && valor.toLowerCase().includes("gmt")) {
                    // Remove quebras de linha e pega só a parte que tem dia, mês e ano
                    const valorLimpo = valor.replace(/\n/g, " ").trim();
                    const match = valorLimpo.match(/[A-Za-z]{3} [A-Za-z]{3} \d{2} \d{4}/);
                    const dataStr = match ? match[0] : valorLimpo;
                    const data = new Date(dataStr);
                    valor = formatarDataBr(data);
                } else if (typeof valor === "string" && !isNaN(Date.parse(valor))) {
                    valor = formatarDataBr(valor);
                } else {
                    valor = String(valor ?? "");
                }

                doc.text(valor, doc.page.margins.left + i * larguraColuna + 2, y + 3, {
                    width: larguraColuna - 4,
                    align: "center"
                });
            });

            y += 15;
        });

        doc.end();

        return new Promise((resolve, reject) => {
            stream.on("finish", () => resolve(caminho));
            stream.on("error", reject);
        });
    };
};
