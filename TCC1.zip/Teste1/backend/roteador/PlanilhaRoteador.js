const express = require("express");
const PlanilhaControle = require("../controle/PlanilhaControle");

module.exports = class PlanilhaRoteador {
    criarRotasPlanilha() {
        const rota = express.Router();
        const controle = new PlanilhaControle();

        rota.get("/", async (req, res) => {
            try {
                const caminho = await controle.gerarPlanilha();
                console.log("Caminho da planilha:", caminho);

                res.download(caminho, (err) => {
                    if (err) {
                        console.error("Erro no download da planilha:", err);
                        res.status(500).send("Erro ao enviar a planilha.");
                    }
                });
            } catch (err) {
                console.error("Erro ao gerar planilha:", err);
                res.status(500).send("Erro ao gerar planilha.");
            }
        });

        return rota;
    }
};