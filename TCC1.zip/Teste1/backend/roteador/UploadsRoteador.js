const express = require("express");
const { UploadControle, buscarFotoPorRG } = require("../controle/UploadsControle"); // ← importa a classe corretamente
const upload = require("../middleware/UploadsMulter");
const JwtMiddleware = require("../middleware/JwtMiddleware");

module.exports = class UploadRoteador {
    constructor() {
        this._router = express.Router();
        this._uploadsControle = new UploadControle(); // ← agora sim, instanciando corretamente
        this._jwtMiddleware = new JwtMiddleware();
    }

    criarRotasUpload = () => {
        this._router.post("/",
            upload.single("photo"),
            this._uploadsControle.uploadFoto);

        this._router.get("/uploads/:rg",
            this._jwtMiddleware.validar_token_acesso,
            buscarFotoPorRG);

        return this._router;
    }
};
