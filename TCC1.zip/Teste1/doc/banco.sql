SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- Criar o banco de dados
CREATE SCHEMA IF NOT EXISTS `tccteste1` DEFAULT CHARACTER SET utf8mb4;
USE `tccteste1`;

CREATE TABLE cargo (
    idCargo INT PRIMARY KEY AUTO_INCREMENT,
    nomeCargo VARCHAR(64) NOT NULL
);

-- Criação da tabela de funcionários
CREATE TABLE funcionario (
    idFuncionario INT PRIMARY KEY AUTO_INCREMENT,
    idCargo INT,
    nomeFuncionario VARCHAR(128) NOT NULL,
    emailFuncionario VARCHAR(64) UNIQUE NOT NULL,
    senhaFuncionario VARCHAR(255) NOT NULL, -- senha deve ser armazenada como hash
    FOREIGN KEY (idCargo) REFERENCES cargo(idCargo)
);

-- Criação da tabela de empresas
CREATE TABLE empresa (
    idEmpresa INT PRIMARY KEY AUTO_INCREMENT,
    nomeEmpresa VARCHAR(128) NOT NULL,
    cnpjEmpresa VARCHAR(20) NOT NULL
);

-- Criação da tabela de visitantes
CREATE TABLE visitante (
    idVisitante INT PRIMARY KEY AUTO_INCREMENT,
    rg VARCHAR(12) UNIQUE NOT NULL,
    nome VARCHAR(128) NOT NULL
);

-- Criação da tabela de registros de visita (alterado para usar RG como chave estrangeira)
CREATE TABLE registro (
    idRegistro INT PRIMARY KEY AUTO_INCREMENT,
    rg VARCHAR(12) NOT NULL,  -- RG agora é usado para identificar o visitante
    idEmpresa INT,
    origem VARCHAR(128),
    horarioEntrada TIME,
    horarioSaida TIME,
    dataVisita DATE NOT NULL,
    idFuncionario INT NOT NULL,
    FOREIGN KEY (rg) REFERENCES visitante(rg),  -- chave estrangeira para RG
    FOREIGN KEY (idEmpresa) REFERENCES empresa(idEmpresa),
    FOREIGN KEY (idFuncionario) REFERENCES funcionario(idFuncionario)
);

SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET SQL_MODE=@OLD_SQL_MODE;
