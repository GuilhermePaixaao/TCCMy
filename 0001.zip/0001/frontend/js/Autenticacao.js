function getPayloadFromToken(){

    const token = localStorage.getItem('token');
    if (!token) return null;

    try{
        const payloadBase64 = token.split('.')[1];
        const payload = JSON.parse(atob(payloadBase64));
        return payload;
    }catch (e){
        console.error('Token inválido ou malformado');
        return null;
    }
}

function getRoleFromToken(){
    const payload = getPayloadFromToken();
      if (payload) {
        return payload.role;
      } 
}

function verificacaoAdm(){
    const token = localStorage.getItem("token");
    if (!token) {
        alert("Erro: Você precisa estar logado.");
        window.location.href = '/login/login.html'
        return;
    }
    
    const role = getRoleFromToken();
    if(role !== "adm"){
        alert('Acesso Negado! Apenas para Administradores');
        window.location.href = '/login/index/funcionario/indexVisitanteFun.html'
        return;
    }
}

function verificacaoLogin(){
    const token = localStorage.getItem('token');
    if (!token) {
        alert("Erro: Você precisa estar logado.");
        window.location.href = '/login/login.html'
        return;
    }
}

function Inicio(){
    const role = getRoleFromToken(); 
    if (role === 'adm'){
        console.log('erro')
        window.location.href = '/login/index/adm/indexAdm.html';
        return;
    }else if(role === 'funcionario'){
        console.log('erro')
        window.location.href = '/login/index/funcionario/visitante/indexVisitanteFun.html';
        return;
    }
}

function InicioVisitante(){
    const role = getRoleFromToken();
    if (role === 'adm'){
        window.location.href = '/login/index/adm/visitante/indexVisitanteAdm.html';
    }else if(role === 'funcionario'){
        window.location.href = '/login/index/funcionario/visitante/indexVisitanteFun.html';
    }
}

function logout() {
    localStorage.removeItem('token');
    window.location.href = '/login/login.html';
  }

function verificacaoCpf(cpf){
    cpf = cpf.replace(/[^\d]+/g, '');

    let soma = 0;
    let resto = 0;

    for (let i = 0; i < 9; i++) {
        soma += parseInt(cpf[i]) * (10 - i);
    }

    resto = soma % 11;
    let digito1 = (resto < 2) ? 0 : 11 - resto;
    if (parseInt(cpf[9]) != digito1) return false;

    soma = 0;

    for (let i = 0; i < 10; i++) {
        soma += parseInt(cpf[i]) * (11 - i);
    }

    resto = soma % 11;
    let digito2 = (resto < 2) ? 0 : 11 - resto;
    if (parseInt(cpf[10]) != digito2) return false;

    return true;
}