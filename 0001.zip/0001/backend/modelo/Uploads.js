const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

// Função que converte o arquivo de imagem para base64
function converterImagemParaBase64(caminhoArquivo) {
    try {
        const dadosImagem = fs.readFileSync(caminhoArquivo);
        const base64 = dadosImagem.toString('base64');
        const extensao = path.extname(caminhoArquivo).substring(1);
        return `data:image/${extensao};base64,${base64}`;
    } catch (erro) {
        console.error('Erro ao converter imagem:', erro.message);
        return null;
    }
}

// Função principal de busca
function getFotoMaisRecentePorCPF(cpf) {
    const hashCPF = crypto.createHash("md5").update(cpf).digest("hex");
    const pastaFotos = path.join(__dirname, "../..", "xdata_srv");
    console.log("Hash do CPF:", hashCPF);

    let arquivos;
    try {
        arquivos = fs.readdirSync(pastaFotos);
    } catch (erro) {
        console.error('Erro ao ler diretório:', erro.message);
        return null;
    }

    const arquivosDoCPF = arquivos
        .filter(nome => nome.startsWith(hashCPF))
        .sort((a, b) => {
            const timestampA = parseInt(a.split("_")[1].split(".")[0]);
            const timestampB = parseInt(b.split("_")[1].split(".")[0]);
            return timestampB - timestampA; // ordem decrescente: mais recente primeiro
        });

    if (arquivosDoCPF.length > 0) {
        const caminhoCompleto = path.join(pastaFotos, arquivosDoCPF[0]);
        console.log("Arquivo encontrado:", caminhoCompleto);
        const base64 = converterImagemParaBase64(caminhoCompleto);
        return base64;
    } else {
        console.log("Nenhuma foto encontrada para o CPF:", cpf);
        return null;
    }
}

function getTodasFotosPorCPF(cpf) {
    const hashCPF = crypto.createHash("md5").update(cpf).digest("hex");
    const pastaFotos = path.join(__dirname, "../..", "xdata_srv");
  
    let arquivos;
    try {
      arquivos = fs.readdirSync(pastaFotos);
    } catch (erro) {
      console.error('Erro ao ler diretório:', erro.message);
      return [];
    }
  
    const arquivosDoCPF = arquivos.filter(nome => nome.startsWith(hashCPF));
  
    const imagens = arquivosDoCPF.map(nome => {
      const caminhoCompleto = path.join(pastaFotos, nome);
      const base64 = converterImagemParaBase64(caminhoCompleto);
      return { nome, base64 };
    }).filter(item => item.base64 !== null);
  
    return imagens;
  }


module.exports = { getFotoMaisRecentePorCPF,
                    getTodasFotosPorCPF};