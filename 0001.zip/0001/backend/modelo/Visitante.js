const Banco = require("./banco");

module.exports = class Visitante {
    constructor() {
        this._nomeVisitante = null;
        this._cpfVisitante = null;
        this._empresaVisitante = null;
        this._origemVisitante = null;
        this._horarioEntrada = null;
        this._horarioSaida = null;
        this._novoCpfVisitante = null;
    }

    // Criação de um novo visitante
    create = async () => {
        const SQL = "INSERT INTO Visitante (nome, cpf) VALUES (?, ?);";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, 
                [this.nomeVisitante, this.cpfVisitante]);
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log(error);
            return false;
        }
    }

    // Lê todos os visitantes
    readAll = async () => {
        const SQL = "SELECT * FROM Visitante;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, []);
            return resultado;
        } catch (error) {
            console.log(error);
            return [];
        }
    }

    // Lê um visitante específico pelo RG
    readByCpf = async () => {
        const SQL = "SELECT * FROM Visitante WHERE cpf = ?;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [this.cpfVisitante]);
            return resultado;
        } catch (error) {
            console.log(error);
            return [];
        }
    }

    update = async () => {
        const conexao = Banco.getConexao().promise();

        try {
            await conexao.query('START TRANSACTION');

            // Atualiza Visitante primeiro
            let SQL = 'UPDATE Visitante SET nome = ?';
            const params = [this.nomeVisitante];

            if (this.novoCpfVisitante) {
                SQL += ', cpf = ?';
                params.push(this.novoCpfVisitante);
            }
            
            

            SQL += ' WHERE cpf = ?';
            params.push(this.cpfVisitante);

            const [resultado] = await conexao.execute(SQL, params);

            // Se tiver novoRgVisitante, atualiza registro depois
            if (this.novoRgVisitante) {
                const sqlRegistro = 'UPDATE registro SET cpf = ? WHERE cpf = ?';
                await conexao.execute(sqlRegistro, [this.novoCpfVisitante, this.cpfVisitante]);
            }

            await conexao.query('COMMIT');

            return resultado.affectedRows > 0;

        } catch (error) {
            await conexao.query('ROLLBACK');
            console.log('Erro no update do visitante com transação:', error);
            return false;
        }
    }

     delete = async () => {
        const SQL = "DELETE FROM Visitante WHERE cpf = ?;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [this.cpfVisitante]);
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log(error);
            return false;
        }
    }

    // Getters and Setters
    get nomeVisitante() { return this._nomeVisitante; }
    set nomeVisitante(value) { this._nomeVisitante = value; }

    get cpfVisitante() { return this._cpfVisitante; }
    set cpfVisitante(value) { this._cpfVisitante = value; }

    get empresaVisitante() { return this._empresaVisitante; }
    set empresaVisitante(value) { this._empresaVisitante = value; }

    get origemVisitante() { return this._origemVisitante; }
    set origemVisitante(value) { this._origemVisitante = value; }

    get horarioEntrada() { return this._horarioEntrada; }
    set horarioEntrada(value) { this._horarioEntrada = value; }

    get horarioSaida() { return this._horarioSaida; }
    set horarioSaida(value) { this._horarioSaida = value; }

    get novoCpfVisitante() {return this._novoCpfVisitante; }
    set novoCpfVisitante(value) {this._novoCpfVisitante = value;}

};
