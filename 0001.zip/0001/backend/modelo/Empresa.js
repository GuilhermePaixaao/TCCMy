const Banco = require("./banco");

module.exports = class Empresa {
    constructor() {
        this._cnpjEmpresa = null;
        this._nomeEmpresa = null;
        this._cnpjEmpresa = null;
        this._contato = null;
        this._telefone = null;
        this._modulo = null;
    }

    create = async () => {
        const SQL = "INSERT INTO empresa (nomeEmpresa, cnpjEmpresa, contato, telefone, modulo) VALUES (?, ?, ?, ?, ?)";
        try {
            console.log("Executando create com nomeEmpresa:", this.nomeEmpresa, this.cnpjEmpresa, this.contato, this.telefone, this.modulo);
            const conexao = Banco.getConexao();
            const [resposta] = await conexao.promise().execute(SQL, [this.nomeEmpresa, this.cnpjEmpresa, this.contato, this.telefone, this.modulo]);
            console.log("Resposta da execução do create:", resposta);
            this.cnpjEmpresa = resposta.insertCnpj;
            return resposta.affectedRows > 0;
        } catch (error) {
            console.error("Erro no create:", error);
            return false;
        }
    }

    delete = async () => {
        const SQL = "UPDATE empresa SET ativo = FALSE WHERE cnpjEmpresa = ?";
        try {
            const conexao = Banco.getConexao();
            const [resposta] = await conexao.promise().execute(SQL, [this.cnpjEmpresa]);
            return resposta.affectedRows > 0;
        } catch (error) {
            console.error("Erro ao ocultar empresa:", error);
            return false;
        }
    };


    update = async () => {
        const SQL = "UPDATE empresa SET nomeEmpresa = ?, contato = ?, telefone = ?, modulo = ? WHERE cnpjEmpresa = ?";
        try {
            const conexao = Banco.getConexao();
            const [resposta] = await conexao.promise().execute(SQL, [
                this.nomeEmpresa,
                this.contato,
                this.telefone,
                this.modulo,
                this.cnpjEmpresa
            ]);
            console.log("Resposta da execução do update:", resposta);
            return resposta.affectedRows > 0;
        } catch (error) {
            console.error("Erro no update:", error);
            return false;
        }
    }

    // Empresa.js
    reativar = async () => {
        const SQL = "UPDATE empresa SET ativo = TRUE WHERE cnpjEmpresa = ?";
        const conexao = Banco.getConexao();
        const [resposta] = await conexao.promise().execute(SQL, [this.cnpjEmpresa]);
        return resposta.affectedRows > 0;
    };

    readInativas = async () => {
        const SQL = "SELECT * FROM empresa WHERE ativo = FALSE";
        try {
            console.log("Buscando empresas inativas...");
            const conexao = Banco.getConexao();
            const [matrizRespostas] = await conexao.promise().execute(SQL);
            console.log("Resultado da busca de inativas:", matrizRespostas);
            return matrizRespostas;
        } catch (error) {
            console.error("Erro ao buscar empresas inativas:", error);
            return [];
        }
    }





    isEmpresa = async () => {
        const SQL = "SELECT COUNT(*) AS qtd FROM empresa WHERE nomeEmpresa = ?";
        try {
            console.log("Verificando existência da empresa com nomeEmpresa:", this.nomeEmpresa);
            const conexao = Banco.getConexao();
            const [resposta] = await conexao.promise().execute(SQL, [this.nomeEmpresa]);
            console.log("Resultado da verificação da empresa:", resposta);
            return resposta[0].qtd > 0;
        } catch (error) {
            console.error("Erro na verificação da empresa:", error);
            return false;
        }
    }

    isEmpresaByCnpj = async () => {
        const SQL = "SELECT COUNT(*) AS qtd FROM empresa WHERE cnpjEmpresa = ?";
        try {
            console.log("Verificando existência da empresa com cnpjEmpresa:", this.cnpjEmpresa);
            const conexao = Banco.getConexao();
            const [resposta] = await conexao.promise().execute(SQL, [this.cnpjEmpresa]);
            console.log("Resultado da verificação da empresa:", resposta);
            return resposta[0].qtd > 0;
        } catch (error) {
            console.error("Erro na verificação da empresa:", error);
            return false;
        }
    }

    readAll = async () => {
        const SQL = "SELECT * FROM empresa WHERE ativo = TRUE";
        try {
            const conexao = Banco.getConexao();
            const [matrizRespostas] = await conexao.promise().execute(SQL);
            return matrizRespostas;
        } catch (error) {
            console.error("Erro ao buscar empresas ativas:", error);
            return [];
        }
    };

    readByCnpj = async () => {
        const SQL = "SELECT * FROM empresa WHERE cnpjEmpresa = ?";
        try {
            console.log("Buscando empresa pelo cnpj:", this.cnpjEmpresa);
            const conexao = Banco.getConexao();
            const [matrizRespostas] = await conexao.promise().execute(SQL, [this.cnpjEmpresa]);
            console.log("Resultado da busca pelo cnpj:", matrizRespostas);
            return matrizRespostas;
        } catch (error) {
            console.error("Erro ao buscar empresa pelo cnpj:", error);
            return [];
        }
    }

    get cnpjEmpresa() {
        return this._cnpjEmpresa;
    }
    set cnpjEmpresa(novoCnpjEmpresa) {
        this._cnpjEmpresa = novoCnpjEmpresa;
    }

    get cnpjEmpresa() {
        return this._cnpjEmpresa;
    }

    set cnpjEmpresa(novoCnpjEmpresa) {
        this._cnpjEmpresa = novoCnpjEmpresa;
    }

    get nomeEmpresa() {
        return this._nomeEmpresa;
    }
    set nomeEmpresa(novoNomeEmpresa) {
        this._nomeEmpresa = novoNomeEmpresa;
    }
}
