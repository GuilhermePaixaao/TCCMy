const Banco = require("./banco");

module.exports = class PlanilhaModelo {
  // Busca todos os visitantes com os dados completos
  async buscarTodosClientes() {
    const conexao = Banco.getConexao();
    return new Promise((resolve, reject) => {
      conexao.execute(
        `
        SELECT 
          visitante.cpf,
          registro.horarioEntrada,
          registro.horarioSaida,
          registro.origem,
          registro.dataVisita,
          empresa.nomeEmpresa,
          funcionario.nomeFuncionario
        FROM registro
        JOIN visitante   ON registro.cpf = visitante.cpf
        JOIN empresa     ON registro.idEmpresa = empresa.idEmpresa
        JOIN funcionario ON registro.idFuncionario = funcionario.idFuncionario;
        `,
        (erro, resultados) => {
          if (erro) {
            reject(erro);
          } else {
            resolve(resultados);
          }
        }
      );
    });
  }

  // Busca visitantes filtrando por nome da empresa (relatório completo)
  async buscarClientesPorEmpresa(nomeDaEmpresa) {
    const conexao = Banco.getConexao();
    return new Promise((resolve, reject) => {
      conexao.execute(
        `
        SELECT 
          visitante.cpf,
          registro.horarioEntrada,
          registro.horarioSaida,
          registro.origem,
          registro.dataVisita,
          empresa.nomeEmpresa,
          funcionario.nomeFuncionario
        FROM registro
        JOIN visitante   ON registro.cpf = visitante.cpf
        JOIN empresa     ON registro.idEmpresa = empresa.idEmpresa
        JOIN funcionario ON registro.idFuncionario = funcionario.idFuncionario
        WHERE empresa.nomeEmpresa = ?;
        `,
        [nomeDaEmpresa],
        (erro, resultados) => {
          if (erro) {
            reject(erro);
          } else {
            resolve(resultados);
          }
        }
      );
    });
  }

  // Busca visitantes filtrando por CPF 
async buscarClientesPorCPF(cpf) {
  const conexao = Banco.getConexao();
  return new Promise((resolve, reject) => {
    console.log("CPF recebido para consulta:", cpf);
    conexao.execute(
      `
   SELECT 
        visitante.cpf,
        registro.horarioEntrada,
        registro.horarioSaida,
        registro.origem,
        registro.dataVisita,
        empresa.nomeEmpresa,
        funcionario.nomeFuncionario
      FROM registro
      JOIN visitante   ON registro.cpf = visitante.cpf
      JOIN empresa     ON registro.idEmpresa = empresa.idEmpresa
      JOIN funcionario ON registro.idFuncionario = funcionario.idFuncionario
      WHERE visitante.cpf = ?;

      `,
      [cpf], // Aqui espera o CPF limpo, só números
      (erro, resultados) => {
        if (erro) {
          reject(erro);
        } else {
          resolve(resultados);
        }
      }
    );
  });
}

 async buscarClientesPorPeriodo(dataInicial, dataFinal) {
  const conexao = Banco.getConexao();
  return new Promise((resolve, reject) => {
    conexao.execute(
      `
      SELECT 
        visitante.cpf,
        registro.horarioEntrada,
        registro.horarioSaida,
        registro.origem,
        registro.dataVisita,
        empresa.nomeEmpresa,
        funcionario.nomeFuncionario
      FROM registro
      JOIN visitante   ON registro.cpf = visitante.cpf
      JOIN empresa     ON registro.idEmpresa = empresa.idEmpresa
      JOIN funcionario ON registro.idFuncionario = funcionario.idFuncionario
      WHERE registro.dataVisita BETWEEN ? AND ?
      ORDER BY registro.dataVisita ASC;
      `,
      [dataInicial, dataFinal],
      (erro, resultados) => {
        if (erro) {
          reject(erro);
        } else {
          resolve(resultados);
        }
      }
    );
  });
}
  
};
