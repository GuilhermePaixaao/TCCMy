const Banco = require("./banco");

module.exports = class Registro {
    constructor() {
        this._idRegistro = null;
        this._cpf = null;
        this._idEmpresa = null;
        this._origem = null;
        this._horarioEntrada = null;
        this._horarioSaida = null;
        this._dataVisita = null;
        this._idFuncionario = null;
        this._nomeFuncionario = null;
        this._nomeEmpresa = null;
    }

    create = async () => {
        // Validação completa dos campos obrigatórios
        if (
            !this.cpf ||
            !this.dataVisita ||
            !this.idEmpresa ||
            !this.idFuncionario ||
            //!this.nomeFuncionario ||
            //!this.nomeEmpresa ||
            !this.origem ||
            !this.horarioEntrada
            
        ) {
            console.log("Erro: Parâmetros obrigatórios ausentes:", {
                cpf: this.cpf,
                idEmpresa: this.idEmpresa,
                idFuncionario: this.idFuncionario,
                //nomeEmpresa: this.nomeEmpresa,
                origem: this.origem,
                horarioEntrada: this.horarioEntrada,
                horarioSaida: this.horarioSaida,
                dataVisita: this.dataVisita,
                //nomeFuncionario: this.nomeFuncionario,
                
                
            });
            return false;
        }
        

        const SQL = `INSERT INTO registro 
        (cpf, idEmpresa , idFuncionario, origem, horarioEntrada, horarioSaida, dataVisita)
        VALUES (?, ?, ?, ?, ?, ?, ?)`;

        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [
                this.cpf,
                this.idEmpresa,
                this.idFuncionario,
                // this.nomeEmpresa,
                this.origem,
                this.horarioEntrada,
                // horarioSaida pode ser opcional, então tratamos aqui:
                this.horarioSaida ?? null,
                this.dataVisita,


            ]);
            this.idRegistro = resultado.insertId;
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log("Erro ao inserir registro:", error);
            return false;
        }
    };

    update = async () => {
        const SQL = `
            UPDATE registro 
            SET nomeEmpresa = ?, origem = ?, horarioEntrada = ?, 
                horarioSaida = ?, dataVisita = ?
            WHERE idRegistro = ?;
        `;

        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [
                this.nomeEmpresa,
                this.origem,
                this.horarioEntrada,
                this.horarioSaida,
                this.dataVisita,
                this.idRegistro
            ]);
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log("Erro ao atualizar registro:", error);
            return false;
        }
    };

    readAll = async () => {
        const SQL = "SELECT * FROM registro_expandido;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL);
            return resultado;
        } catch (error) {
            console.log("Erro ao buscar registros:", error);
            return [];
        }
    };


    readById = async () => {
        const SQL = "SELECT * FROM registro WHERE idRegistro = ?;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [this.idRegistro]);
            return resultado;
        } catch (error) {
            console.log(error);
            return [];
        }
    };

    delete = async () => {
        const SQL = "DELETE FROM registro WHERE idRegistro = ?;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [this.idRegistro]);
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log(error);
            return false;
        }
    };

    // Getters e Setters
    get nomeEmpresa() { return this._nomeEmpresa; }
    set nomeEmpresa(value) { this._nomeEmpresa = value; }

    get nomeFuncionario() { return this._nomeFuncionario; }
    set nomeFuncionario(value) { this._nomeFuncionario = value; }


    get idRegistro() { return this._idRegistro; }
    set idRegistro(value) { this._idRegistro = value; }

    get cpfVisitante() { return this._cpfVisitante; }
    set cpfVisitante(value) { this._cpfVisitante = value; }

    get idEmpresa() { return this._idEmpresa; }
    set idEmpresa(value) { this._idEmpresa = value; }

    get origem() { return this._origem; }
    set origem(value) { this._origem = value; }

    get horarioEntrada() { return this._horarioEntrada; }
    set horarioEntrada(value) { this._horarioEntrada = value; }

    get horarioSaida() { return this._horarioSaida; }
    set horarioSaida(value) { this._horarioSaida = value; }

    get dataVisita() { return this._dataVisita; }
    set dataVisita(value) { this._dataVisita = value; }

    get idFuncionario() { return this._idFuncionario; }
    set idFuncionario(value) { this._idFuncionario = value; }
};
