const express = require("express");
const EmpresaMiddleware = require("../middleware/EmpresaMiddleware");
const EmpresaControle = require("../controle/EmpresaControle");
const JwtMiddleware = require("../middleware/JwtMiddleware");

module.exports = class EmpresaRoteador {
    constructor() {
        this._router = express.Router();
        this._empresaMiddleware = new EmpresaMiddleware();
        this._controleEmpresa = new EmpresaControle();
        this._jwtMiddleware = new JwtMiddleware();
    }

    criarRotasEmpresa = () => {
        this._router.post("/",
            this._empresaMiddleware.validar_nomeEmpresa,
            this._empresaMiddleware.validar_empresa_nao_existe,
            this._controleEmpresa.empresa_create_controle
        );

        this._router.get("/",
            this._controleEmpresa.empresa_readAll_controle
        );
        this._router.get("/inativas", this._controleEmpresa.empresa_readInativas_controle);

        this._router.get("/:cnpjEmpresa",
            this._controleEmpresa.empresa_readByCnpj_controle
        );

        this._router.put("/:cnpjEmpresa",
            this._controleEmpresa.empresa_update_controle
        );
        this._router.put("/reativar/:cnpjEmpresa", this._controleEmpresa.empresa_reativar_controle);

        this._router.delete("/:cnpjEmpresa",
            this._controleEmpresa.empresa_delete_controle
        );
        // EmpresaRoteador.js
       
        


        return this._router;
    }

    get jwtMiddleware() {
        return this._jwtMiddleware;
    }
    set jwtMiddleware(in_jwtMiddleware) {
        this._jwtMiddleware = in_jwtMiddleware;
    }

    get controleEmpresa() {
        return this._controleEmpresa;
    }
    set controleEmpresa(_controleEmpresa) {
        this._controleEmpresa = _controleEmpresa;
    }

    get empresaMiddleware() {
        return this._empresaMiddleware;
    }
    set empresaMiddleware(_empresaMiddleware) {
        this._empresaMiddleware = _empresaMiddleware;
    }

    get router() {
        return this._router;
    }
    set router(router) {
        this._router = router;
    }
}
