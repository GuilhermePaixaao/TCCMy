const express = require("express");
const PlanilhaControle = require("../controle/PlanilhaControle");

module.exports = class PlanilhaRoteador {
  criarRotasPlanilha() {
    const rota = express.Router();
    const controle = new PlanilhaControle();

    // 📄 Gera a planilha completa
    rota.get("/", async (req, res) => {
      try {
        const caminho = await controle.gerarPlanilha();
        console.log("Caminho da planilha:", caminho);

        res.download(caminho, (err) => {
          if (err) {
            console.error("Erro no download da planilha:", err);
            res.status(500).send("Erro ao enviar a planilha.");
          }
        });
      } catch (err) {
        console.error("Erro ao gerar planilha:", err);
        res.status(500).send("Erro ao gerar planilha.");
      }
    });

    // 📄 Gera planilha filtrando por CPF
   rota.get("/filtro/cpf/pdf", async (req, res) => {
  const cpf = req.query.cpf;

  if (!cpf || typeof cpf !== "string") {
    return res.status(400).send("Parâmetro 'cpf' é obrigatório.");
  }

  try {
    const caminho = await controle.gerarPlanilhaPorCPF(cpf);
    res.download(caminho, (err) => {
      if (err) {
        console.error("Erro ao enviar PDF por CPF:", err);
        res.status(500).send("Erro ao enviar o PDF.");
      }
    });
  } catch (err) {
    console.error("Erro ao gerar planilha por CPF:", err);
    res.status(500).send("Erro ao gerar planilha por CPF.");
  }
});

    // 📄 Gera planilha filtrando por empresa
    rota.get("/filtro/empresa/pdf", async (req, res) => {
      const nomeEmpresa = req.query.nomeEmpresa;

      if (!nomeEmpresa || typeof nomeEmpresa !== "string") {
        return res.status(400).send("Parâmetro 'nomeEmpresa' é obrigatório.");
      }

      try {
        const caminho = await controle.gerarPlanilhaPorEmpresa(nomeEmpresa);
        res.download(caminho, (err) => {
          if (err) {
            console.error("Erro ao enviar PDF por empresa:", err);
            res.status(500).send("Erro ao enviar o PDF.");
          }
        });
      } catch (err) {
        console.error("Erro ao gerar planilha por empresa:", err);
        res.status(500).send("Erro ao gerar planilha por empresa.");
      }
    });

    // 📄 Gera planilha filtrando por período
    rota.post("/filtro/periodo/pdf", async (req, res) => {
  const { dataInicial, dataFinal } = req.body;
  if (!dataInicial || !dataFinal) {
    return res.status(400).send("Parâmetros 'dataInicial' e 'dataFinal' são obrigatórios.");
  }
  try {
    const caminho = await controle.gerarPlanilhaPorPeriodo(dataInicial, dataFinal);
    res.download(caminho, err => {
      if (err) {
        console.error("Erro ao enviar PDF por período:", err);
        res.status(500).send("Erro ao enviar o PDF.");
      }
    });
  } catch (err) {
    console.error("Erro ao gerar planilha por período:", err);
    res.status(500).send("Erro ao gerar planilha por período.");
  }
});

    return rota;
  }
};
