const Registro = require("../modelo/Registro");

module.exports = class RegistroControle {
    constructor() {
        this._registro = new Registro();
    }

    // Criar um novo registro de visita
    registro_create_controle = async (req, res) => {
        try {
            const {
                cpf,
                idEmpresa,
                origem,
                horarioEntrada,
                horarioSaida,
                dataVisita,
                idFuncionario
            } = req.body;

            console.log("Body recebido:", req.body);

            this._registro.cpf = cpf;
            this._registro.idEmpresa = idEmpresa;
            this._registro.origem = origem;
            this._registro.horarioEntrada = horarioEntrada;
            this._registro.horarioSaida = horarioSaida;
            this._registro.dataVisita = dataVisita;
            this._registro.idFuncionario = idFuncionario;

            const sucesso = await this._registro.create();
            if (sucesso) {
                res.status(201).json({ mensagem: "Registro de visita criado com sucesso!" });
            } else {
                res.status(500).json({ mensagem: "Erro ao criar registro de visita." });
            }
        } catch (error) {
            console.error("Erro no registro_create_controle:", error);
            res.status(500).json({ mensagem: "Erro interno no servidor.", erro: error });
        }
    };

    // Atualizar qualquer campo de um registro de visita
    registro_update_controle = async (req, res) => {
        try {
            const { idRegistro } = req.params;
            const {
                idEmpresa,
                origem,
                horarioEntrada,
                horarioSaida,
                dataVisita,
            } = req.body;

            this._registro.idRegistro = idRegistro;
            this._registro.idEmpresa = idEmpresa;
            this._registro.origem = origem;
            this._registro.horarioEntrada = horarioEntrada;
            this._registro.horarioSaida = horarioSaida;
            this._registro.dataVisita = dataVisita;

            const sucesso = await this._registro.update();
            if (sucesso) {
                res.status(200).json({ mensagem: "Registro atualizado com sucesso!" });
            } else {
                res.status(400).json({ mensagem: "Registro não encontrado ou erro na atualização." });
            }
        } catch (error) {
            console.error("Erro no registro_update_controle:", error);
            res.status(500).json({ mensagem: "Erro interno no servidor.", erro: error });
        }
    };

    // Buscar todos os registros de visita
    registro_readAll_controle = async (req, res) => {
        try {
            const registros = await this._registro.readAll();
            res.status(200).json(registros);
        } catch (error) {
            console.error("Erro no registro_readAll_controle:", error);
            res.status(500).json({ mensagem: "Erro ao buscar registros.", erro: error });
        }
    };

    // Buscar um registro específico pelo ID
    registro_readById_controle = async (req, res) => {
        try {
            const { idRegistro } = req.params;
            this._registro.idRegistro = idRegistro;

            const registro = await this._registro.readById();
            if (registro.length > 0) {
                res.status(200).json(registro[0]);
            } else {
                res.status(404).json({ mensagem: "Registro não encontrado." });
            }
        } catch (error) {
            console.error("Erro no registro_readById_controle:", error);
            res.status(500).json({ mensagem: "Erro ao buscar registro.", erro: error });
        }
    };

    // Deletar um registro de visita
    registro_delete_controle = async (req, res) => {
        try {
            const { idRegistro } = req.params;
            this._registro.idRegistro = idRegistro;

            const sucesso = await this._registro.delete();
            if (sucesso) {
                res.status(200).json({ mensagem: "Registro deletado com sucesso!" });
            } else {
                res.status(400).json({ mensagem: "Erro ao deletar registro ou registro não encontrado." });
            }
        } catch (error) {
            console.error("Erro no registro_delete_controle:", error);
            res.status(500).json({ mensagem: "Erro interno no servidor.", erro: error });
        }
    };
};
