-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

CREATE SCHEMA IF NOT EXISTS `tccteste1` DEFAULT CHARACTER SET utf8mb4;
USE `tccteste1`;

-- -------------------------------
-- Table `cargo`
-- -------------------------------
CREATE TABLE IF NOT EXISTS `cargo` (
  `idCargo` INT(11) NOT NULL AUTO_INCREMENT,
  `nomeCargo` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`idCargo`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- -------------------------------
-- Table `empresa`
-- -------------------------------
CREATE TABLE IF NOT EXISTS `empresa` (
  `idEmpresa` INT(11) NOT NULL AUTO_INCREMENT,
  `nomeEmpresa` VARCHAR(128) NOT NULL,
  `cnpjEmpresa` VARCHAR(18) NOT NULL,
  `contato` VARCHAR(128) NOT NULL,
  `telefone` VARCHAR(13) NOT NULL,
  `modulo` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`idEmpresa`),
  UNIQUE INDEX `cnpjEmpresa` (`cnpjEmpresa`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- -------------------------------
-- Table `funcionario`
-- -------------------------------
CREATE TABLE IF NOT EXISTS `funcionario` (
  `idFuncionario` INT(11) NOT NULL AUTO_INCREMENT,
  `idCargo` INT(11) DEFAULT NULL,
  `nomeFuncionario` VARCHAR(128) NOT NULL,
  `cpfFuncionario` VARCHAR(64) NOT NULL,
  `senhaFuncionario` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`idFuncionario`),
  UNIQUE INDEX `cpfFuncionario` (`cpfFuncionario`),
  INDEX `idCargo` (`idCargo`),
  CONSTRAINT `funcionario_ibfk_1`
    FOREIGN KEY (`idCargo`) REFERENCES `cargo` (`idCargo`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- -------------------------------
-- Table `visitante`
-- -------------------------------
CREATE TABLE IF NOT EXISTS `visitante` (
  `idVisitante` INT(11) NOT NULL AUTO_INCREMENT,
  `cpf` VARCHAR(14) NOT NULL,
  `nome` VARCHAR(128) NOT NULL,
  PRIMARY KEY (`idVisitante`),
  UNIQUE INDEX `cpf` (`cpf`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- -------------------------------
-- Table `registro` com FOREIGN KEYS
-- -------------------------------
CREATE TABLE IF NOT EXISTS `registro` (
  `idRegistro` INT(11) NOT NULL AUTO_INCREMENT,
  `cpf` VARCHAR(14) NOT NULL,
  `idEmpresa` INT(11) DEFAULT NULL,
  `idFuncionario` INT(11) NOT NULL,
  `origem` VARCHAR(128) DEFAULT NULL,
  `horarioEntrada` TIME DEFAULT NULL,
  `horarioSaida` TIME DEFAULT NULL,
  `dataVisita` DATE NOT NULL,
  PRIMARY KEY (`idRegistro`),
  INDEX `cpf` (`cpf`),
  INDEX `idEmpresa` (`idEmpresa`),
  INDEX `idFuncionario` (`idFuncionario`),
  CONSTRAINT `registro_ibfk_1`
    FOREIGN KEY (`cpf`) REFERENCES `visitante` (`cpf`),
  CONSTRAINT `registro_ibfk_2`
    FOREIGN KEY (`idEmpresa`) REFERENCES `empresa` (`idEmpresa`),
  CONSTRAINT `registro_ibfk_3`
    FOREIGN KEY (`idFuncionario`) REFERENCES `funcionario` (`idFuncionario`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- -------------------------------
-- VIEW com nomes
-- -------------------------------
CREATE OR REPLACE VIEW `registro_expandido` AS
SELECT 
  r.idRegistro,
  r.cpf,
  v.nome AS nomeVisitante,
  e.nomeEmpresa,
  f.nomeFuncionario,
  r.origem,
  r.horarioEntrada,
  r.horarioSaida,
  r.dataVisita
FROM registro r
JOIN empresa e ON r.idEmpresa = e.idEmpresa
JOIN funcionario f ON r.idFuncionario = f.idFuncionario
JOIN visitante v ON r.cpf = v.cpf;
ALTER TABLE registro
DROP FOREIGN KEY registro_ibfk_2;

ALTER TABLE registro
ADD CONSTRAINT registro_ibfk_2
FOREIGN KEY (idEmpresa)
REFERENCES empresa(idEmpresa)
ON DELETE SET NULL;
ALTER TABLE empresa ADD ativo BOOLEAN NOT NULL DEFAULT TRUE;
/*UPDATE empresa SET ativo = TRUE WHERE cnpjEmpresa = ?; Reativar a empresa*/



-- -------------------------------
-- Inserts iniciais
-- -------------------------------
INSERT INTO `cargo` (`idCargo`, `nomeCargo`) VALUES (1, 'adm'), (2, 'funcionario');

INSERT INTO `funcionario` (`idFuncionario`, `idCargo`, `nomeFuncionario`, `cpfFuncionario`, `senhaFuncionario`) 
VALUES (1, 1, 'adm', '481.516.648-00', '202cb962ac59075b964b07152d234b70');

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
